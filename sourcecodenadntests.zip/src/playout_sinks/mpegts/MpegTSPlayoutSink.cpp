// Repository: Retrovue-playout
// Component: MPEG-TS Playout Sink
// Purpose: Encodes decoded frames to H.264, muxes to MPEG-TS, streams over TCP.
// Copyright (c) 2025 RetroVue

#include "retrovue/playout_sinks/mpegts/MpegTSPlayoutSink.hpp"
#include "retrovue/playout_sinks/mpegts/PTSController.hpp"
#include "retrovue/playout_sinks/mpegts/EncoderPipeline.hpp"
#include "retrovue/playout_sinks/mpegts/ClockUtils.hpp"

#include <chrono>
#include <iostream>
#include <iomanip>
#include <ctime>
#include <cmath>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <fcntl.h>
#include <unistd.h>
#include <errno.h>
#include <cstring>

// Include FakeMasterClock header for dynamic_cast (only needed in .cpp, not in header)
#include "../../../tests/fixtures/mpegts_sink/FakeMasterClock.h"

namespace retrovue::playout_sinks::mpegts {

// C-style callback for FFmpeg AVIO
extern "C" int writePacketCallback(void* opaque, uint8_t* buf, int buf_size) {
  auto* sink = reinterpret_cast<MpegTSPlayoutSink*>(opaque);
  return sink->writeToSocketNonBlocking(buf, buf_size);
}

MpegTSPlayoutSink::MpegTSPlayoutSink(
    std::shared_ptr<retrovue::buffer::FrameRingBuffer> frame_buffer,
    std::shared_ptr<retrovue::timing::MasterClock> master_clock,
    const MpegTSPlayoutSinkConfig& config)
    : config_(config),
      frame_buffer_(std::move(frame_buffer)),
      master_clock_(std::move(master_clock)),
      internal_state_(InternalState::Idle),
      running_(false),
      stop_requested_(false),
      listen_fd_(-1),
      client_fd_(-1),
      client_connected_(false),
      pts_controller_(std::make_unique<PTSController>()),
      encoder_pipeline_(std::make_unique<EncoderPipeline>(config_)),
      frames_sent_(0),
      frames_dropped_(0),
      late_frames_(0),
      encoding_errors_(0),
      network_errors_(0),
      buffer_underruns_(0),
      late_frame_drops_(0),
      is_fake_clock_(false) {
  // Detect if we're using a FakeMasterClock for testing
  is_fake_clock_ = (dynamic_cast<retrovue::tests::fixtures::mpegts_sink::FakeMasterClock*>(
      master_clock_.get()) != nullptr);
}

MpegTSPlayoutSink::MpegTSPlayoutSink(
    std::shared_ptr<retrovue::buffer::FrameRingBuffer> frame_buffer,
    std::shared_ptr<retrovue::timing::MasterClock> master_clock,
    const MpegTSPlayoutSinkConfig& config,
    std::unique_ptr<EncoderPipeline> encoder_pipeline)
    : config_(config),
      frame_buffer_(std::move(frame_buffer)),
      master_clock_(std::move(master_clock)),
      internal_state_(InternalState::Idle),
      running_(false),
      stop_requested_(false),
      listen_fd_(-1),
      client_fd_(-1),
      client_connected_(false),
      pts_controller_(std::make_unique<PTSController>()),
      encoder_pipeline_(std::move(encoder_pipeline)),
      frames_sent_(0),
      frames_dropped_(0),
      late_frames_(0),
      encoding_errors_(0),
      network_errors_(0),
      buffer_underruns_(0),
      late_frame_drops_(0),
      is_fake_clock_(false) {
  // Detect if we're using a FakeMasterClock for testing
  is_fake_clock_ = (dynamic_cast<retrovue::tests::fixtures::mpegts_sink::FakeMasterClock*>(
      master_clock_.get()) != nullptr);
}

MpegTSPlayoutSink::~MpegTSPlayoutSink() {
  stop();
}

bool MpegTSPlayoutSink::start() {
  std::lock_guard<std::mutex> lock(state_mutex_);

  if (running_.load(std::memory_order_acquire)) {
    return false;  // Already running
  }

  if (internal_state_ != InternalState::Idle) {
    return false;  // Can only start from Idle state
  }

  // Initialize TCP socket (create, bind, listen)
  if (!initializeSocket()) {
    internal_state_ = InternalState::Error;
    return false;
  }

  internal_state_ = InternalState::WaitingForClient;

  // Note: PTS mapping will be initialized on first frame (per timing contract T-002)
  // We don't set sink_start_time_utc_us_ here - it will be set when first frame is processed
  sink_start_time_recorded_ = false;
  
  std::cout << "[MpegTSPlayoutSink] Started | PTS mapping will be initialized on first frame" << std::endl;

  // Start accept thread (non-blocking accept loop)
  stop_requested_.store(false, std::memory_order_release);
  running_.store(true, std::memory_order_release);
  accept_thread_ = std::thread(&MpegTSPlayoutSink::acceptThread, this);

  // Note: Encoder pipeline is initialized when client connects

  // Start worker thread
  stop_requested_.store(false, std::memory_order_release);
  running_.store(true, std::memory_order_release);
  worker_thread_ = std::thread(&MpegTSPlayoutSink::workerLoop, this);

  internal_state_ = InternalState::Running;

  return true;
}

void MpegTSPlayoutSink::stop() {
  if (!running_.load(std::memory_order_acquire)) {
    return;  // Not running
  }

  std::lock_guard<std::mutex> lock(state_mutex_);

  if (internal_state_ == InternalState::Stopped) {
    return;  // Already stopped
  }

  // Signal stop
  stop_requested_.store(true, std::memory_order_release);

  // Wait for worker thread to exit
  if (worker_thread_.joinable()) {
    worker_thread_.join();
  }

  // Wait for accept thread to exit (if running)
  if (accept_thread_.joinable()) {
    accept_thread_.join();
  }

  // Close encoder pipeline
  encoder_pipeline_->close();

  // Cleanup socket
  cleanupSocket();

  running_.store(false, std::memory_order_release);
  internal_state_ = InternalState::Stopped;
}

bool MpegTSPlayoutSink::isRunning() const {
  return running_.load(std::memory_order_acquire);
}

InternalState MpegTSPlayoutSink::state() const {
  std::lock_guard<std::mutex> lock(state_mutex_);
  return internal_state_;
}

std::string MpegTSPlayoutSink::name() const {
  return "MpegTSPlayoutSink";
}

MpegTSPlayoutSink::SinkStats MpegTSPlayoutSink::getStats() const {
  SinkStats stats;
  stats.frames_sent = frames_sent_.load(std::memory_order_relaxed);
  stats.frames_dropped = frames_dropped_.load(std::memory_order_relaxed);
  stats.late_frames = late_frames_.load(std::memory_order_relaxed);
  stats.encoding_errors = encoding_errors_.load(std::memory_order_relaxed);
  stats.network_errors = network_errors_.load(std::memory_order_relaxed);
  stats.buffer_underruns = buffer_underruns_.load(std::memory_order_relaxed);
  stats.late_frame_drops = late_frame_drops_.load(std::memory_order_relaxed);
  return stats;
}

void MpegTSPlayoutSink::workerLoop() {
  // Timing constants
  constexpr int64_t kMaxLateToleranceUs = 50'000;  // 50ms tolerance for late frames
  constexpr int64_t kSoftWaitThresholdUs = 5'000;   // 5ms - sleep if ahead by more
  constexpr int64_t kWaitFudgeUs = 500;             // 500µs - wake slightly before deadline
  constexpr int64_t kMinSleepUs = 100;              // 100µs minimum sleep to avoid busy loop
  constexpr int64_t kUnderrunBackoffUs = 5'000;     // 5ms backoff on underrun
  constexpr int64_t kMaxSpinWaitUs = 1'000;         // 1ms - spin-wait only for very short waits

  // Calculate frame duration in microseconds
  const int64_t frame_duration_us = static_cast<int64_t>(
      1'000'000.0 / config_.target_fps);

  uint64_t frame_counter = 0;   // Frame sequence number for logging

  while (running_.load(std::memory_order_acquire) &&
         !stop_requested_.load(std::memory_order_acquire)) {
    // Poll master clock for current time (ALWAYS pull from MasterClock)
    const int64_t now_us = master_clock_->now_utc_us();

    // Try to accept new client connection (non-blocking)
    tryAcceptClient();

    // Try to drain output queue first (send pending packets)
    drainOutputQueue();

    // Check output queue size to decide if we should encode new frames
    size_t queue_size = 0;
    {
      std::lock_guard<std::mutex> lock(output_queue_mutex_);
      queue_size = output_queue_.size();
    }

    // Only encode new frames if queue is below high-water mark
    if (queue_size >= config_.output_queue_high_water_mark) {
      std::this_thread::sleep_for(std::chrono::microseconds(kMinSleepUs));
      continue;
    }

    // Check buffer overflow (producer too fast)
    const size_t buffer_size = frame_buffer_->Size();
    const size_t buffer_capacity = frame_buffer_->Capacity();
    if (buffer_size >= buffer_capacity * 0.9) {  // 90% full
      static uint64_t overflow_warning_count = 0;
      if (overflow_warning_count++ % 100 == 0) {  // Throttle warnings
        std::cout << "[MpegTSPlayoutSink] DEBUG: Buffer near full | "
                  << "buffer=" << buffer_size << "/" << buffer_capacity << std::endl;
      }
    }

    // Peek at next frame (non-destructive)
    const retrovue::buffer::Frame* next_frame = frame_buffer_->Peek();

    // Note: PTS mapping will be initialized when we process the frame below

    if (next_frame == nullptr) {
      // Buffer is empty - handle underflow
      handleBufferUnderflow(now_us);

      // Block waiting for frame (but do NOT shift the program clock)
      if (master_clock_->is_fake()) {
        // Fake clock — check for idle timeout (end-of-stream detection)
        constexpr int64_t kMaxFakeIdleAfterLastFrameUs = 1'000'000;  // 1 second
        
        if (frames_emitted_ > 0 && 
            last_frame_emit_utc_us_ > 0 &&
            (now_us - last_frame_emit_utc_us_) > kMaxFakeIdleAfterLastFrameUs) {
          std::cout << "[MpegTSPlayoutSink] Fake clock idle timeout "
                    << "(no frames, stream drained) — exiting worker loop" << std::endl;
          // Signal stop so accept thread can also exit cleanly
          // Note: We set stop_requested_ but NOT running_ - let stop() handle cleanup
          stop_requested_.store(true, std::memory_order_release);
          break;  // Exit the worker loop so stop() can join cleanly
        }
        
        // Fake clock — advance time by 1ms to prevent infinite spinning
        // This allows tests to proceed deterministically
        auto* fake_clock = dynamic_cast<retrovue::tests::fixtures::mpegts_sink::FakeMasterClock*>(
            master_clock_.get());
        if (fake_clock) {
          fake_clock->advance_us(1000);  // Advance by 1ms
        }
        // Sleep for 1ms to allow other threads to run
        std::this_thread::sleep_for(std::chrono::milliseconds(1));
      } else {
        // Real clock — normal sleep
        std::this_thread::sleep_for(
            std::chrono::microseconds(kUnderrunBackoffUs));
      }
      continue;
    }

    // Extract pts_usec from frame metadata
    const int64_t pts_usec = next_frame->metadata.pts;

    // Calculate target station time for this frame
    int64_t target_time_us = 0;
    int64_t gap_us = 0;

    if (sink_start_time_recorded_) {
      target_time_us = sink_start_time_utc_us_ + pts_usec;
      gap_us = now_us - target_time_us;
    } else {
      // PTS mapping not initialized - initialize it on the first frame we see
      sink_start_time_utc_us_ = now_us - pts_usec;
      sink_start_time_recorded_ = true;
      target_time_us = sink_start_time_utc_us_ + pts_usec;
      gap_us = now_us - target_time_us;
      std::cout << "[MpegTSPlayoutSink] PTS mapping initialized on frame | "
                << "pts_zero_utc_us=" << sink_start_time_utc_us_ << " | "
                << "frame_pts=" << pts_usec << " | "
                << "now_us=" << now_us << std::endl;
    }

    // Handle early frames (ahead of schedule)
    if (gap_us < -kSoftWaitThresholdUs) {
      if (master_clock_->is_fake()) {
        // For fake clock, process frame immediately (no sleep)
      } else {
        // Frame is early - sleep until closer to deadline (real clock only)
        const int64_t wait_us = (-gap_us) - kWaitFudgeUs;
        if (wait_us > kMaxSpinWaitUs) {
          std::this_thread::sleep_for(std::chrono::microseconds(wait_us));
          // Log sleep event
          std::cout << "[MpegTSPlayoutSink] Sleeping for timing | "
                    << "wait=" << (wait_us / 1000) << "ms | "
                    << "target_time=" << target_time_us << " | "
                    << "now=" << now_us << std::endl;
          if (!running_.load(std::memory_order_acquire) ||
              stop_requested_.load(std::memory_order_acquire)) {
            break;
          }
          continue;
        } else {
          std::this_thread::sleep_for(std::chrono::microseconds(kMinSleepUs));
          continue;
        }
      }
    }

    // Handle late frames (beyond tolerance)
    if (gap_us > kMaxLateToleranceUs) {
      // Frame is too late - drop it
      retrovue::buffer::Frame dropped_frame;
      if (frame_buffer_->Pop(dropped_frame)) {
        late_frame_drops_.fetch_add(1, std::memory_order_relaxed);
        frames_dropped_.fetch_add(1, std::memory_order_relaxed);
        late_frames_.fetch_add(1, std::memory_order_relaxed);

        // Log the drop
        std::cout << "[MpegTSPlayoutSink] Dropped late frame | "
                  << "gap=" << (gap_us / 1000) << "ms | "
                  << "pts_usec=" << dropped_frame.metadata.pts << " | "
                  << "buffer=" << frame_buffer_->Size() << "/"
                  << frame_buffer_->Capacity() << std::endl;
      }
      continue;
    }

    // Frame is on time or slightly late (within tolerance) - emit it
    retrovue::buffer::Frame frame;
    if (!frame_buffer_->Pop(frame)) {
      continue;
    }

    // Log late frame if slightly late (within tolerance but still late)
    if (gap_us > 0) {
      late_frames_.fetch_add(1, std::memory_order_relaxed);
      std::cout << "[MpegTSPlayoutSink] Late frame (within tolerance) | "
                << "gap=" << (gap_us / 1000) << "ms | "
                << "pts_usec=" << frame.metadata.pts << " | "
                << "emitting immediately" << std::endl;
    }

    // Calculate PTS in 90kHz units for encoder
    const int64_t pts90k = (pts_usec * 90000) / 1'000'000;

    // Process the frame (encode and send)
    processFrame(frame, now_us, pts90k, frame_counter, gap_us);

    // Update statistics
    frames_sent_.fetch_add(1, std::memory_order_relaxed);
    frame_counter++;
    
    // Track frame emission for fake clock idle detection
    frames_emitted_++;
    last_frame_emit_utc_us_ = now_us;

    // Small sleep to avoid busy-waiting (≤ 1ms granularity)
    std::this_thread::sleep_for(std::chrono::microseconds(kMinSleepUs));

    // Log that we're continuing the loop every 10 frames
    if (frame_counter % 10 == 0) {
      std::cout << "[MpegTSPlayoutSink] Worker loop continuing | frame_counter=" << frame_counter
                << " | buffer=" << frame_buffer_->Size() << "/" << frame_buffer_->Capacity() << std::endl;
    }
  }
}

void MpegTSPlayoutSink::processFrame(const retrovue::buffer::Frame& frame,
                                     int64_t master_time_us,
                                     int64_t pts90k,
                                     uint64_t frame_number,
                                     int64_t drift_us) {
  // Log frame emission with all required details
  auto now = std::chrono::system_clock::now();
  auto time_t = std::chrono::system_clock::to_time_t(now);
  auto ms = std::chrono::duration_cast<std::chrono::milliseconds>(
                now.time_since_epoch()) %
            1000;

  // Format drift with µs symbol
  const char* drift_sign = (drift_us >= 0) ? "+" : "";
  const int64_t drift_abs_us = std::abs(drift_us);

  std::cout << "[MpegTSPlayoutSink] Emit frame #" << frame_number
            << " | pts_usec=" << frame.metadata.pts
            << " | PTS_90kHz=" << pts90k
            << " | output_timestamp=" << master_time_us
            << " | ts=" << std::put_time(std::localtime(&time_t), "%Y-%m-%d %H:%M:%S")
            << "." << std::setfill('0') << std::setw(3) << ms.count()
            << " | drift=" << drift_sign << drift_abs_us << "µs"
            << " | buffer=" << frame_buffer_->Size() << "/"
            << frame_buffer_->Capacity() << std::endl;

  // Phase 6: Real encoding via EncoderPipeline
  bool client_connected = client_connected_.load(std::memory_order_acquire);
  if (client_connected) {
    if (!encoder_pipeline_->encodeFrame(frame, pts90k)) {
      encoding_errors_.fetch_add(1, std::memory_order_relaxed);
      std::cerr << "[MpegTSPlayoutSink] Encoding failed for frame #" << frame_number << std::endl;
      // Continue processing - don't block the producer
    }
  } else {
    // No client connected - skip encoding (frame is dropped)
    // This saves CPU when no one is watching
  }
}

void MpegTSPlayoutSink::handleBufferUnderflow(int64_t master_time_us) {
  // Increment underrun counter
  buffer_underruns_.fetch_add(1, std::memory_order_relaxed);

  // Log WARNING for underflow (as required)
  std::cerr << "[MpegTSPlayoutSink] WARNING: Buffer underflow | "
            << "underruns=" << buffer_underruns_.load(std::memory_order_relaxed)
            << " | buffer=0/" << frame_buffer_->Capacity()
            << " | now_utc_us=" << master_time_us << std::endl;
}

void MpegTSPlayoutSink::handleBufferOverflow(int64_t master_time_us) {
  // Late frame dropping is handled in the worker loop
}

bool MpegTSPlayoutSink::initializeSocket() {
  // Create TCP socket
  listen_fd_ = socket(AF_INET, SOCK_STREAM, 0);
  if (listen_fd_ < 0) {
    std::cerr << "[MpegTSPlayoutSink] Failed to create socket: " 
              << strerror(errno) << std::endl;
    return false;
  }

  // Set socket options: SO_REUSEADDR to allow quick reuse
  int reuse = 1;
  if (setsockopt(listen_fd_, SOL_SOCKET, SO_REUSEADDR, &reuse, sizeof(reuse)) < 0) {
    std::cerr << "[MpegTSPlayoutSink] Failed to set SO_REUSEADDR: " 
              << strerror(errno) << std::endl;
    close(listen_fd_);
    listen_fd_ = -1;
    return false;
  }

  // Set listen socket to non-blocking
  int flags = fcntl(listen_fd_, F_GETFL, 0);
  if (flags < 0 || fcntl(listen_fd_, F_SETFL, flags | O_NONBLOCK) < 0) {
    std::cerr << "[MpegTSPlayoutSink] Failed to set non-blocking: " 
              << strerror(errno) << std::endl;
    close(listen_fd_);
    listen_fd_ = -1;
    return false;
  }

  // Bind to address and port
  struct sockaddr_in addr;
  std::memset(&addr, 0, sizeof(addr));
  addr.sin_family = AF_INET;
  addr.sin_port = htons(config_.port);
  
  if (config_.bind_host == "0.0.0.0" || config_.bind_host.empty()) {
    addr.sin_addr.s_addr = INADDR_ANY;
  } else {
    if (inet_pton(AF_INET, config_.bind_host.c_str(), &addr.sin_addr) <= 0) {
      std::cerr << "[MpegTSPlayoutSink] Invalid bind address: " 
                << config_.bind_host << std::endl;
      close(listen_fd_);
      listen_fd_ = -1;
      return false;
    }
  }

  if (bind(listen_fd_, (struct sockaddr*)&addr, sizeof(addr)) < 0) {
    std::cerr << "[MpegTSPlayoutSink] Failed to bind to " << config_.bind_host 
              << ":" << config_.port << ": " << strerror(errno) << std::endl;
    close(listen_fd_);
    listen_fd_ = -1;
    return false;
  }

  // Listen for connections (backlog of 1 - only accept one client at a time)
  if (listen(listen_fd_, 1) < 0) {
    std::cerr << "[MpegTSPlayoutSink] Failed to listen: " 
              << strerror(errno) << std::endl;
    close(listen_fd_);
    listen_fd_ = -1;
    return false;
  }

  std::cout << "[MpegTSPlayoutSink] Listening on " << config_.bind_host 
            << ":" << config_.port << std::endl;
  return true;
}

void MpegTSPlayoutSink::cleanupSocket() {
  // Close client socket if connected
  if (client_fd_ >= 0) {
    close(client_fd_);
    client_fd_ = -1;
  }
  
  // Close listen socket
  if (listen_fd_ >= 0) {
    close(listen_fd_);
    listen_fd_ = -1;
  }
  
  client_connected_.store(false, std::memory_order_release);
  
  // Clear output queue
  std::lock_guard<std::mutex> lock(output_queue_mutex_);
  output_queue_.clear();
}

void MpegTSPlayoutSink::acceptThread() {
  while (running_.load(std::memory_order_acquire) &&
         !stop_requested_.load(std::memory_order_acquire)) {
    tryAcceptClient();
    
    // Sleep briefly to avoid busy-waiting
    // Check stop_requested_ before and during sleep to exit quickly
    if (stop_requested_.load(std::memory_order_acquire)) {
      break;
    }
    
    if (master_clock_->is_fake()) {
      // Fake clock — minimal sleep to allow stop_requested_ check
      // This allows the thread to exit quickly when stop_requested_ is set
      std::this_thread::sleep_for(std::chrono::milliseconds(1));
    } else {
      // Real clock — use chunked sleep to check stop_requested_ frequently
      constexpr int64_t sleep_ms = 100;
      constexpr int64_t chunk_ms = 10;  // Check every 10ms
      int64_t remaining = sleep_ms;
      
      while (remaining > 0 && 
             running_.load(std::memory_order_acquire) &&
             !stop_requested_.load(std::memory_order_acquire)) {
        auto step = std::min<int64_t>(remaining, chunk_ms);
        std::this_thread::sleep_for(std::chrono::milliseconds(step));
        remaining -= step;
      }
    }
  }
}

bool MpegTSPlayoutSink::tryAcceptClient() {
  // If already connected, don't accept another
  if (client_connected_.load(std::memory_order_acquire)) {
    return false;
  }

  if (listen_fd_ < 0) {
    return false;
  }

  struct sockaddr_in client_addr;
  socklen_t addr_len = sizeof(client_addr);
  int new_client_fd = accept(listen_fd_, (struct sockaddr*)&client_addr, &addr_len);

  if (new_client_fd < 0) {
    if (errno == EAGAIN || errno == EWOULDBLOCK) {
      return false;
    } else {
      std::cerr << "[MpegTSPlayoutSink] Accept error: " << strerror(errno) << std::endl;
      return false;
    }
  }

  // Set client socket to non-blocking
  int flags = fcntl(new_client_fd, F_GETFL, 0);
  if (flags < 0 || fcntl(new_client_fd, F_SETFL, flags | O_NONBLOCK) < 0) {
    std::cerr << "[MpegTSPlayoutSink] Failed to set client socket non-blocking: " 
              << strerror(errno) << std::endl;
    close(new_client_fd);
    return false;
  }

  // Store client file descriptor
  client_fd_ = new_client_fd;
  client_connected_.store(true, std::memory_order_release);

  // Log connection
  char client_ip[INET_ADDRSTRLEN];
  inet_ntop(AF_INET, &client_addr.sin_addr, client_ip, INET_ADDRSTRLEN);
  std::cout << "[MpegTSPlayoutSink] Client connected from " << client_ip 
            << ":" << ntohs(client_addr.sin_port) << std::endl;

  // Initialize encoder for new client
  if (!initializeEncoderForClient()) {
    std::cerr << "[MpegTSPlayoutSink] Failed to initialize encoder for client" << std::endl;
    handleClientDisconnect();
    return false;
  }

  return true;
}

void MpegTSPlayoutSink::handleClientDisconnect() {
  if (!client_connected_.load(std::memory_order_acquire)) {
    return;  // Already disconnected
  }

  std::cout << "[MpegTSPlayoutSink] Client disconnected" << std::endl;

  // Close client socket
  if (client_fd_ >= 0) {
    close(client_fd_);
    client_fd_ = -1;
  }

  // Mark as disconnected
  client_connected_.store(false, std::memory_order_release);

  // Clear output queue (client is gone, no point keeping packets)
  {
    std::lock_guard<std::mutex> lock(output_queue_mutex_);
    output_queue_.clear();
  }

  // Close encoder pipeline (will reopen on next client)
  encoder_pipeline_->close();

  // Reset encoder state for next client
}

bool MpegTSPlayoutSink::initializeEncoderForClient() {
  encoder_pipeline_->close();

  // Use C-style callback for FFmpeg AVIO (nonblocking mode)
  return encoder_pipeline_->open(config_, this, writePacketCallback);
}

bool MpegTSPlayoutSink::sendToSocket(const uint8_t* data, size_t size) {
  if (!client_connected_.load(std::memory_order_acquire) || client_fd_ < 0) {
    return false;
  }

  size_t sent = 0;
  while (sent < size) {
    ssize_t result = send(client_fd_, data + sent, size - sent, MSG_DONTWAIT | MSG_NOSIGNAL);
    
    if (result < 0) {
      if (errno == EAGAIN || errno == EWOULDBLOCK) {
        // Socket buffer is full - partial send
        return sent > 0;
      } else if (errno == EPIPE || errno == ECONNRESET) {
        handleClientDisconnect();
        network_errors_.fetch_add(1, std::memory_order_relaxed);
        return false;
      } else {
        std::cerr << "[MpegTSPlayoutSink] Send error: " << strerror(errno) << std::endl;
        handleClientDisconnect();
        network_errors_.fetch_add(1, std::memory_order_relaxed);
        return false;
      }
    } else if (result == 0) {
      handleClientDisconnect();
      network_errors_.fetch_add(1, std::memory_order_relaxed);
      return false;
    } else {
      sent += static_cast<size_t>(result);
    }
  }

  return true;  // All data sent
}

// FFmpeg-safe write function: always returns buf_size, never blocks
int MpegTSPlayoutSink::writeToSocketNonBlocking(uint8_t* buf, int buf_size) {
  if (!client_connected_.load(std::memory_order_acquire)) {
    return buf_size;
  }

  int sock = client_fd_;
  if (sock < 0) {
    client_connected_.store(false, std::memory_order_release);
    return buf_size;
  }

  ssize_t sent = send(sock, buf, buf_size, MSG_DONTWAIT | MSG_NOSIGNAL);

  if (sent == buf_size) {
    return buf_size;
  }

  if (sent < 0) {
    if (errno == EAGAIN || errno == EWOULDBLOCK) {
      dropped_packets_.fetch_add(1, std::memory_order_relaxed);
      return buf_size;
    }
    client_connected_.store(false, std::memory_order_release);
    close(sock);
    client_fd_ = -1;
    return buf_size;
  }

  dropped_packets_.fetch_add(1, std::memory_order_relaxed);
  return buf_size;
}

size_t MpegTSPlayoutSink::drainOutputQueue() {
  if (!client_connected_.load(std::memory_order_acquire)) {
    return 0;  // No client connected - can't send
  }

  size_t packets_sent = 0;
  
  std::lock_guard<std::mutex> lock(output_queue_mutex_);
  
  while (!output_queue_.empty()) {
    EncodedPacket& packet = output_queue_.front();
    
    // Try to send packet (non-blocking)
    bool sent = sendToSocket(packet.data.data(), packet.data.size());
    
    if (!sent) {
      break;
    }
    
    output_queue_.pop_front();
    packets_sent++;
  }
  
  return packets_sent;
}

bool MpegTSPlayoutSink::queueEncodedPacket(PacketType type, std::vector<uint8_t> data, int64_t pts90k) {
  std::lock_guard<std::mutex> lock(output_queue_mutex_);
  
  // Check if queue is at capacity
  if (output_queue_.size() >= config_.max_output_queue_packets) {
    // Queue overflow - drop oldest packet
    if (!output_queue_.empty()) {
      output_queue_.pop_front();
      packets_dropped_.fetch_add(1, std::memory_order_relaxed);
      
      // Log warning (throttled to avoid spam)
      static uint64_t last_warning = 0;
      uint64_t current_drops = packets_dropped_.load(std::memory_order_relaxed);
      if (current_drops % 10 == 1 || current_drops == 1) {
        std::cerr << "[MpegTSPlayoutSink] Output queue overflow - dropping packets. "
                  << "Total dropped: " << current_drops << std::endl;
      }
    }
  }
  
  // Add packet to queue
  output_queue_.emplace_back(type, std::move(data), pts90k);
  return true;
}

}  // namespace retrovue::playout_sinks::mpegts
