// Repository: Retrovue-playout
// Component: Encoder Pipeline
// Purpose: Owns FFmpeg encoder/muxer handles and manages encoding lifecycle.
// Copyright (c) 2025 RetroVue

#include "retrovue/playout_sinks/mpegts/EncoderPipeline.hpp"
#include "retrovue/playout_sinks/mpegts/MpegTSPlayoutSinkConfig.hpp"
#include "retrovue/buffer/FrameRingBuffer.h"

#include <iostream>
#include <iomanip>
#include <chrono>
#include <ctime>
#include <sstream>
#include <cstring>
#include <algorithm>

#ifdef RETROVUE_FFMPEG_AVAILABLE
#include <libavutil/dict.h>
#include <libavutil/time.h>
#include <libavutil/mathematics.h>  // For av_rescale_q
#endif

namespace retrovue::playout_sinks::mpegts {

#ifdef RETROVUE_FFMPEG_AVAILABLE

EncoderPipeline::EncoderPipeline(const MpegTSPlayoutSinkConfig& config)
    : config_(config),
      initialized_(false),
      codec_ctx_(nullptr),
      format_ctx_(nullptr),
      video_stream_(nullptr),
      frame_(nullptr),
      input_frame_(nullptr),
      packet_(nullptr),
      sws_ctx_(nullptr),
      frame_width_(0),
      frame_height_(0),
      input_pix_fmt_(AV_PIX_FMT_YUV420P),
      sws_ctx_valid_(false),
      header_written_(false),
      avio_opaque_(nullptr),
      avio_write_callback_(nullptr),
      custom_avio_ctx_(nullptr),
      last_pts_90k_(0),
      last_dts_90k_(0),
      last_pts_valid_(false),
      last_dts_valid_(false),
      last_pcr_90k_(0),
      last_pcr_packet_time_us_(0),
      last_pcr_valid_(false),
      last_write_time_us_(0),
      last_packet_time_us_(0) {
  time_base_.num = 1;
  time_base_.den = 90000;  // MPEG-TS timebase is 90kHz
}

EncoderPipeline::~EncoderPipeline() {
  close();
}

bool EncoderPipeline::open(const MpegTSPlayoutSinkConfig& config) {
  return open(config, nullptr, nullptr);
}

bool EncoderPipeline::open(const MpegTSPlayoutSinkConfig& config, 
                            void* opaque,
                            int (*write_callback)(void* opaque, uint8_t* buf, int buf_size)) {
  if (initialized_) {
    return true;  // Already initialized
  }

  if (config.stub_mode) {
    std::cout << "[EncoderPipeline] Stub mode enabled - skipping real encoding" << std::endl;
    initialized_ = true;
    return true;
  }

  // Store write callback and opaque pointer if provided
  avio_opaque_ = opaque;
  avio_write_callback_ = write_callback;

  std::string url;
  if (avio_write_callback_) {
    // Custom AVIO mode - use callback instead of URL
    url = "dummy://";  // Dummy URL for format context
    std::cout << "[EncoderPipeline] Opening encoder pipeline with custom AVIO (nonblocking mode)" << std::endl;
  } else {
    // Traditional URL mode - use TCP socket directly
    std::ostringstream url_stream;
    url_stream << "tcp://" << config.bind_host << ":" << config.port << "?listen=1";
    url = url_stream.str();
    std::cout << "[EncoderPipeline] Opening encoder pipeline: " << url << std::endl;
  }

  // Allocate format context
  int ret = avformat_alloc_output_context2(&format_ctx_, nullptr, "mpegts", url.c_str());
  if (ret < 0 || !format_ctx_) {
    char errbuf[AV_ERROR_MAX_STRING_SIZE];
    av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
    std::cerr << "[EncoderPipeline] Failed to allocate output context: " << errbuf << std::endl;
    return false;
  }
  
  // Note: FFmpeg mpegts muxer inserts PCR automatically (~40ms cadence)
  // Format options can be passed to avformat_write_header if needed
  // For now, use default muxer behavior
  
  // If using custom AVIO, set up custom write callback
  if (avio_write_callback_) {
    // Allocate smaller buffer for AVIO (16KB buffer) to reduce blocking risk
    // Smaller buffer means less data can accumulate before backpressure is felt
    const size_t buffer_size = 16 * 1024;  // 16KB instead of 64KB
    uint8_t* buffer = (uint8_t*)av_malloc(buffer_size);
    if (!buffer) {
      std::cerr << "[EncoderPipeline] Failed to allocate AVIO buffer" << std::endl;
      close();
      return false;
    }
    
    // Create custom AVIO context with write callback
    // Use the provided callback directly (not our wrapper)
    custom_avio_ctx_ = avio_alloc_context(
        buffer, buffer_size, 1, avio_opaque_, nullptr, avio_write_callback_, nullptr);
    if (!custom_avio_ctx_) {
      std::cerr << "[EncoderPipeline] Failed to allocate AVIO context" << std::endl;
      av_free(buffer);
      close();
      return false;
    }
    
    // Explicitly mark as non-blocking (required on some FFmpeg builds)
    custom_avio_ctx_->seekable = 0;
    
    // Set AVIO context on format context
    format_ctx_->pb = custom_avio_ctx_;
    format_ctx_->flags |= AVFMT_FLAG_CUSTOM_IO;
  }

  // Find H.264 encoder
  const AVCodec* codec = avcodec_find_encoder(AV_CODEC_ID_H264);
  if (!codec) {
    std::cerr << "[EncoderPipeline] H.264 encoder not found" << std::endl;
    close();
    return false;
  }

  // Create video stream
  video_stream_ = avformat_new_stream(format_ctx_, codec);
  if (!video_stream_) {
    std::cerr << "[EncoderPipeline] Failed to create video stream" << std::endl;
    close();
    return false;
  }

  video_stream_->id = format_ctx_->nb_streams - 1;

  // Allocate codec context
  codec_ctx_ = avcodec_alloc_context3(codec);
  if (!codec_ctx_) {
    std::cerr << "[EncoderPipeline] Failed to allocate codec context" << std::endl;
    close();
    return false;
  }

  // Set codec parameters
  // Note: Frame dimensions will be set from first frame
  codec_ctx_->codec_id = AV_CODEC_ID_H264;
  codec_ctx_->codec_type = AVMEDIA_TYPE_VIDEO;
  codec_ctx_->pix_fmt = AV_PIX_FMT_YUV420P;
  codec_ctx_->bit_rate = config.bitrate;
  codec_ctx_->gop_size = config.gop_size;
  codec_ctx_->max_b_frames = 0;  // No B-frames for low latency
  codec_ctx_->time_base.num = 1;
  codec_ctx_->time_base.den = static_cast<int>(config.target_fps);
  codec_ctx_->framerate.num = static_cast<int>(config.target_fps);
  codec_ctx_->framerate.den = 1;

  // Set stream time base to 90kHz (MPEG-TS standard)
  video_stream_->time_base.num = 1;
  video_stream_->time_base.den = 90000;

  // Copy codec parameters to stream
  ret = avcodec_parameters_from_context(video_stream_->codecpar, codec_ctx_);
  if (ret < 0) {
    char errbuf[AV_ERROR_MAX_STRING_SIZE];
    av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
    std::cerr << "[EncoderPipeline] Failed to copy codec parameters: " << errbuf << std::endl;
    close();
    return false;
  }

  // Open codec (dimensions will be set from first frame)
  // We'll open it after we get the first frame dimensions
  codec_ctx_->width = 0;
  codec_ctx_->height = 0;

  // Allocate frame, input frame, and packet
  frame_ = av_frame_alloc();
  input_frame_ = av_frame_alloc();
  packet_ = av_packet_alloc();
  if (!frame_ || !input_frame_ || !packet_) {
    std::cerr << "[EncoderPipeline] Failed to allocate frame, input_frame, or packet" << std::endl;
    close();
    return false;
  }

  initialized_ = true;
  std::cout << "[EncoderPipeline] Encoder pipeline initialized (will set dimensions from first frame)" << std::endl;
  return true;
}

bool EncoderPipeline::encodeFrame(const retrovue::buffer::Frame& frame, int64_t pts90k) {
  if (!initialized_) {
    return false;
  }

  if (config_.stub_mode) {
    // Stub mode: just log
    std::cout << "[EncoderPipeline] encodeFrame() - stub mode | PTS_us=" << frame.metadata.pts
              << " | size=" << frame.width << "x" << frame.height << std::endl;
    return true;
  }

  // Stall detection: check if encoder/muxer has stalled
  auto now = std::chrono::steady_clock::now();
  int64_t now_us = std::chrono::duration_cast<std::chrono::microseconds>(
      now.time_since_epoch()).count();
  
  if (last_packet_time_us_ > 0 && 
      (now_us - last_packet_time_us_) > kStallTimeoutUs) {
    std::cerr << "[EncoderPipeline] WARNING: Encoder/muxer stall detected | "
              << "time_since_last_packet=" << ((now_us - last_packet_time_us_) / 1000) << "ms" << std::endl;
    // Don't return false - allow recovery attempt
  }
  
  // Also check write callback stall
  if (last_write_time_us_ > 0 && 
      (now_us - last_write_time_us_) > kStallTimeoutUs) {
    std::cerr << "[EncoderPipeline] WARNING: Write callback stall detected | "
              << "time_since_last_write=" << ((now_us - last_write_time_us_) / 1000) << "ms" << std::endl;
  }

  // Check if codec needs to be opened (first frame or dimensions changed)
  if (!codec_ctx_->width || !codec_ctx_->height || 
      codec_ctx_->width != frame.width || codec_ctx_->height != frame.height) {
    
    // Close existing codec if already open
    if (codec_ctx_->width > 0 && codec_ctx_->height > 0) {
      avcodec_close(codec_ctx_);
      if (frame_->data[0]) {
        av_freep(&frame_->data[0]);
      }
      // Invalidate swscale context (will be recreated with new dimensions)
      if (sws_ctx_) {
        sws_freeContext(sws_ctx_);
        sws_ctx_ = nullptr;
      }
      sws_ctx_valid_ = false;
    }
    
    // Free input frame buffer if it exists
    if (input_frame_->data[0]) {
      av_freep(&input_frame_->data[0]);
    }

    // Set dimensions
    codec_ctx_->width = frame.width;
    codec_ctx_->height = frame.height;
    frame_width_ = frame.width;
    frame_height_ = frame.height;

    // Update stream codec parameters
    video_stream_->codecpar->width = frame.width;
    video_stream_->codecpar->height = frame.height;

    // Re-copy codec parameters to stream (with new dimensions)
    int ret = avcodec_parameters_from_context(video_stream_->codecpar, codec_ctx_);
    if (ret < 0) {
      char errbuf[AV_ERROR_MAX_STRING_SIZE];
      av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
      std::cerr << "[EncoderPipeline] Failed to copy codec parameters: " << errbuf << std::endl;
      return false;
    }

    // Find encoder
    const AVCodec* codec = avcodec_find_encoder(AV_CODEC_ID_H264);
    if (!codec) {
      std::cerr << "[EncoderPipeline] H.264 encoder not found" << std::endl;
      return false;
    }

    // Set encoder options for low latency using AVDictionary
    // This is more reliable than av_opt_set and works with all FFmpeg versions
    AVDictionary* opts = nullptr;
    av_dict_set(&opts, "preset", "ultrafast", 0);
    av_dict_set(&opts, "tune", "zerolatency", 0);

    // Open codec with options
    ret = avcodec_open2(codec_ctx_, codec, &opts);
    if (ret < 0) {
      char errbuf[AV_ERROR_MAX_STRING_SIZE];
      av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
      std::cerr << "[EncoderPipeline] Failed to open codec: " << errbuf << std::endl;
      av_dict_free(&opts);
      return false;
    }
    
    // Free options dictionary (options are now applied to codec context)
    // Note: avcodec_open2 consumes the options, so we free the dictionary
    av_dict_free(&opts);

    // Allocate frame buffer
    ret = av_image_alloc(frame_->data, frame_->linesize,
                         frame.width, frame.height, AV_PIX_FMT_YUV420P, 32);
    if (ret < 0) {
      std::cerr << "[EncoderPipeline] Failed to allocate frame buffer" << std::endl;
      return false;
    }

    frame_->width = frame.width;
    frame_->height = frame.height;
    frame_->format = AV_PIX_FMT_YUV420P;

    // Invalidate swscale context (will be recreated after input_frame_ is allocated)
    if (sws_ctx_) {
      sws_freeContext(sws_ctx_);
      sws_ctx_ = nullptr;
    }
    sws_ctx_valid_ = false;

    // Write header if not already written
    if (!header_written_) {
      // Only open AVIO if using URL mode (not custom AVIO)
      if (!avio_write_callback_ && !(format_ctx_->oformat->flags & AVFMT_NOFILE)) {
        ret = avio_open(&format_ctx_->pb, format_ctx_->url, AVIO_FLAG_WRITE);
        if (ret < 0) {
          char errbuf[AV_ERROR_MAX_STRING_SIZE];
          av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
          std::cerr << "[EncoderPipeline] Failed to open output: " << errbuf << std::endl;
          return false;
        }
      }

      // Write stream header (only on first frame)
      // Note: This may call the write callback, which should be non-blocking
      // If write callback returns EAGAIN, avformat_write_header should handle it
      ret = avformat_write_header(format_ctx_, nullptr);
      if (ret < 0) {
        char errbuf[AV_ERROR_MAX_STRING_SIZE];
        av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
        
        // If header write fails with EAGAIN, it means write callback couldn't write
        // This shouldn't block, but log it and return false to retry later
        if (ret == AVERROR(EAGAIN)) {
          std::cerr << "[EncoderPipeline] Header write blocked (EAGAIN) - will retry on next frame" << std::endl;
          return false;  // Retry on next frame
        }
        
        std::cerr << "[EncoderPipeline] Failed to write header: " << errbuf << std::endl;
        return false;
      }
      header_written_ = true;
      std::cout << "[EncoderPipeline] Header written successfully" << std::endl;
    }

    std::cout << "[EncoderPipeline] Codec opened: " << frame.width << "x" << frame.height << std::endl;
  }

  // Map frame data directly into AVFrame without copying (per instructions)
  // Frame.data is YUV420 planar (Y, U, V planes stored contiguously)
  // We need to copy planes into frame_->data[] with proper linesize
  // since AVFrame expects separate plane pointers
  
  // Verify frame data size
  size_t y_size = frame.width * frame.height;
  size_t uv_size = (frame.width / 2) * (frame.height / 2);
  size_t expected_size = y_size + 2 * uv_size;
  
  if (frame.data.size() < expected_size) {
    std::cerr << "[EncoderPipeline] Frame data too small: got " << frame.data.size()
              << " bytes, expected " << expected_size << " bytes" << std::endl;
    return false;
  }

  // Copy Y, U, V planes directly from frame.data into frame_->data[]
  // Y plane: width * height bytes
  const uint8_t* y_plane = frame.data.data();
  for (int y = 0; y < frame.height; y++) {
    memcpy(frame_->data[0] + y * frame_->linesize[0],
           y_plane + y * frame.width,
           frame.width);
  }

  // U plane: (width/2) * (height/2) bytes
  const uint8_t* u_plane = frame.data.data() + y_size;
  for (int y = 0; y < frame.height / 2; y++) {
    memcpy(frame_->data[1] + y * frame_->linesize[1],
           u_plane + y * (frame.width / 2),
           frame.width / 2);
  }

  // V plane: (width/2) * (height/2) bytes
  const uint8_t* v_plane = frame.data.data() + y_size + uv_size;
  for (int y = 0; y < frame.height / 2; y++) {
    memcpy(frame_->data[2] + y * frame_->linesize[2],
           v_plane + y * (frame.width / 2),
           frame.width / 2);
  }

  // Set frame format explicitly (already YUV420P)
  frame_->format = AV_PIX_FMT_YUV420P;

  // Set frame properties
  // Convert PTS from microseconds to encoder timebase
  // Frame.metadata.pts is in microseconds
  // codec_ctx_->time_base is 1/fps (e.g., 1/30 for 30fps)
  // Formula: pts_in_tb = pts_us * tb.den / (tb.num * 1'000'000)
  // Using av_rescale_q: convert from {1, 1000000} (microseconds) to codec_ctx_->time_base
  AVRational us_timebase = {1, 1000000};  // Microseconds timebase
  frame_->pts = av_rescale_q(frame.metadata.pts, us_timebase, codec_ctx_->time_base);
  // Note: pkt_duration is deprecated in newer FFmpeg versions, but still works
  // Duration is calculated from time_base and frame rate in the encoder

  // Send frame to encoder
  int send_ret = avcodec_send_frame(codec_ctx_, frame_);
  if (send_ret < 0) {
    char errbuf[AV_ERROR_MAX_STRING_SIZE];
    av_strerror(send_ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
    
    // EAGAIN means encoder is busy - try to drain packets first
    if (send_ret == AVERROR(EAGAIN)) {
      // Encoder is full - drain packets to make room
      // This handles encoder backpressure
      // Limit drain attempts to prevent infinite loops
      constexpr int max_drain_attempts = 5;
      int drain_attempts = 0;
      
      while (drain_attempts < max_drain_attempts) {
        int drain_ret = avcodec_receive_packet(codec_ctx_, packet_);
        if (drain_ret == AVERROR(EAGAIN) || drain_ret == AVERROR_EOF) {
          break;  // No more packets available
        }
        if (drain_ret < 0) {
          // Error draining - continue anyway
          break;
        }
        
        drain_attempts++;
        
        // Write drained packet
        packet_->stream_index = video_stream_->index;
        av_packet_rescale_ts(packet_, codec_ctx_->time_base, video_stream_->time_base);
        
        int write_ret = av_interleaved_write_frame(format_ctx_, packet_);
        if (write_ret < 0) {
          if (write_ret == AVERROR(EAGAIN)) {
            // Muxer backpressure - drop packet and break to prevent blocking
            std::cerr << "[EncoderPipeline] Muxer backpressure during drain - dropping packet" << std::endl;
            av_packet_unref(packet_);
            break;  // Stop draining to prevent blocking
          } else {
            // Log error but continue
            char write_errbuf[AV_ERROR_MAX_STRING_SIZE];
            av_strerror(write_ret, write_errbuf, AV_ERROR_MAX_STRING_SIZE);
            std::cerr << "[EncoderPipeline] Error writing drained packet: " << write_errbuf << std::endl;
          }
        }
        
        av_packet_unref(packet_);
      }
      
      // Try sending frame again after draining
      send_ret = avcodec_send_frame(codec_ctx_, frame_);
      if (send_ret == AVERROR(EAGAIN)) {
        // Still full - frame will be processed on next iteration
        return true;  // Not an error, just backpressure
      }
    }
    
    if (send_ret < 0) {
      // Real error
      std::cerr << "[EncoderPipeline] Error sending frame: " << errbuf << std::endl;
      return false;
    }
  }

  // Receive encoded packets (may produce zero or more packets per input frame)
  // Handle encoder backpressure: EAGAIN means no packet available yet
  // Limit number of packets processed per frame to prevent infinite loops
  constexpr int max_packets_per_frame = 10;  // Safety limit
  int packets_processed = 0;
  
  while (packets_processed < max_packets_per_frame) {
    int recv_ret = avcodec_receive_packet(codec_ctx_, packet_);
    
    if (recv_ret == AVERROR(EAGAIN)) {
      // No packet available yet - this is normal (encoder needs more input)
      // This is backpressure, not an error
      break;
    }
    
    if (recv_ret == AVERROR_EOF) {
      // Encoder is flushed - no more packets
      break;
    }
    
    if (recv_ret < 0) {
      // Real error
      char errbuf[AV_ERROR_MAX_STRING_SIZE];
      av_strerror(recv_ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
      std::cerr << "[EncoderPipeline] Error receiving packet: " << errbuf << std::endl;
      return false;
    }

    packets_processed++;

    // Packet received successfully
    // Set packet stream index and timestamp
    packet_->stream_index = video_stream_->index;
    
    // Convert PTS from codec timebase to stream timebase (90kHz)
    av_packet_rescale_ts(packet_, codec_ctx_->time_base, video_stream_->time_base);
    
    // Validate PTS/DTS monotonicity
    if (packet_->pts != AV_NOPTS_VALUE) {
      int64_t pts_90k = packet_->pts;
      
      if (last_pts_valid_) {
        if (pts_90k <= last_pts_90k_) {
          static uint64_t pts_warning_count = 0;
          if (pts_warning_count++ % 100 == 0) {
            std::cerr << "[EncoderPipeline] PTS non-monotonic warning | "
                      << "last_pts=" << last_pts_90k_ << " | "
                      << "current_pts=" << pts_90k << " | "
                      << "diff=" << (pts_90k - last_pts_90k_) << std::endl;
          }
        }
      }
      
      last_pts_90k_ = pts_90k;
      last_pts_valid_ = true;
    }
    
    if (packet_->dts != AV_NOPTS_VALUE) {
      int64_t dts_90k = packet_->dts;
      
      // Validate DTS <= PTS (if both present)
      if (packet_->pts != AV_NOPTS_VALUE && dts_90k > packet_->pts) {
        static uint64_t dts_warning_count = 0;
        if (dts_warning_count++ % 100 == 0) {
          std::cerr << "[EncoderPipeline] DTS > PTS warning | "
                    << "dts=" << dts_90k << " | "
                    << "pts=" << packet_->pts << std::endl;
        }
      }
      
      if (last_dts_valid_) {
        if (dts_90k < last_dts_90k_) {
          static uint64_t dts_warning_count = 0;
          if (dts_warning_count++ % 100 == 0) {
            std::cerr << "[EncoderPipeline] DTS non-monotonic warning | "
                      << "last_dts=" << last_dts_90k_ << " | "
                      << "current_dts=" << dts_90k << std::endl;
          }
        }
      }
      
      last_dts_90k_ = dts_90k;
      last_dts_valid_ = true;
    }
    
    // Update packet time for stall detection
    auto now = std::chrono::steady_clock::now();
    last_packet_time_us_ = std::chrono::duration_cast<std::chrono::microseconds>(
        now.time_since_epoch()).count();

    // Write packet to muxer
    // Note: Even though our callback always returns buf_size, av_interleaved_write_frame
    // might still block internally. However, with our callback implementation,
    // it should not block since we always pretend success.
    if (packets_processed == 1) {
      std::cout << "[EncoderPipeline] Writing packet #" << packets_processed << " to muxer" << std::endl;
    }
    int write_ret = av_interleaved_write_frame(format_ctx_, packet_);
    
    if (packets_processed == 1) {
      std::cout << "[EncoderPipeline] av_interleaved_write_frame returned: " << write_ret << std::endl;
    }
    
    if (write_ret < 0) {
      char errbuf[AV_ERROR_MAX_STRING_SIZE];
      av_strerror(write_ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
      
      // Handle muxer backpressure
      if (write_ret == AVERROR(EAGAIN)) {
        // Muxer would block - drop this packet and break to prevent infinite loop
        // The packet will be lost, but we can't block the timing loop
        std::cerr << "[EncoderPipeline] Muxer backpressure (EAGAIN) - dropping packet to prevent blocking" << std::endl;
        av_packet_unref(packet_);
        // Break out of loop to prevent infinite retry
        break;
      }
      
      // Other errors - log but continue (non-fatal)
      std::cerr << "[EncoderPipeline] Error writing packet: " << errbuf << std::endl;
      av_packet_unref(packet_);
      // Non-fatal: continue to next packet
      continue;
    }

    // Packet written successfully
    if (packets_processed == 1) {
      std::cout << "[EncoderPipeline] Packet written successfully, unrefing" << std::endl;
    }
    av_packet_unref(packet_);
    if (packets_processed == 1) {
      std::cout << "[EncoderPipeline] Packet unrefed, continuing loop" << std::endl;
    }
  }
  
  if (packets_processed >= max_packets_per_frame) {
    std::cerr << "[EncoderPipeline] WARNING: Processed " << packets_processed 
              << " packets (limit reached) - may have more packets to process" << std::endl;
  }

  std::cout << "[EncoderPipeline] encodeFrame returning true, processed " << packets_processed << " packets" << std::endl;
  return true;
}

void EncoderPipeline::close() {
  if (!initialized_) {
    return;
  }

  if (config_.stub_mode) {
    std::cout << "[EncoderPipeline] close() - stub mode" << std::endl;
    initialized_ = false;
    return;
  }

#ifdef RETROVUE_FFMPEG_AVAILABLE
  // Flush encoder
  if (codec_ctx_ && codec_ctx_->width > 0) {
    // Send NULL frame to flush
    avcodec_send_frame(codec_ctx_, nullptr);
    
    // Receive remaining packets
    while (true) {
      int ret = avcodec_receive_packet(codec_ctx_, packet_);
      if (ret == AVERROR(EAGAIN) || ret == AVERROR_EOF) {
        break;
      }
      if (ret >= 0) {
        packet_->stream_index = video_stream_->index;
        av_packet_rescale_ts(packet_, codec_ctx_->time_base, video_stream_->time_base);
        
        // Validate PTS/DTS for flushed packets
        if (packet_->pts != AV_NOPTS_VALUE) {
          int64_t pts_90k = packet_->pts;
          if (last_pts_valid_ && pts_90k <= last_pts_90k_) {
            std::cerr << "[EncoderPipeline] Flushed packet PTS non-monotonic" << std::endl;
          }
          last_pts_90k_ = pts_90k;
          last_pts_valid_ = true;
        }
        
        // Write flushed packet (check for errors)
        int write_ret = av_interleaved_write_frame(format_ctx_, packet_);
        if (write_ret < 0 && write_ret != AVERROR(EAGAIN)) {
          char errbuf[AV_ERROR_MAX_STRING_SIZE];
          av_strerror(write_ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
          std::cerr << "[EncoderPipeline] Error writing flushed packet: " << errbuf << std::endl;
        }
        
        av_packet_unref(packet_);
      }
    }
  }

  // Write trailer (finalizes TS stream, writes final PCR if needed)
  if (format_ctx_ && header_written_) {
    int ret = av_write_trailer(format_ctx_);
    if (ret < 0) {
      char errbuf[AV_ERROR_MAX_STRING_SIZE];
      av_strerror(ret, errbuf, AV_ERROR_MAX_STRING_SIZE);
      std::cerr << "[EncoderPipeline] Error writing trailer: " << errbuf << std::endl;
    } else {
      std::cout << "[EncoderPipeline] Trailer written successfully" << std::endl;
    }
  }
  
  // Flush any remaining complete TS packets in alignment buffer
  // This ensures no partial TS packets are left (partial packets are discarded)
  const size_t ts_packet_size = 188;
  if (!packet_alignment_buffer_.empty()) {
    size_t complete_packets = (packet_alignment_buffer_.size() / ts_packet_size) * ts_packet_size;
    
    if (complete_packets > 0) {
      // Write complete packets
      if (avio_write_callback_ && avio_opaque_) {
        avio_write_callback_(avio_opaque_, packet_alignment_buffer_.data(), complete_packets);
        ProcessTSPackets(packet_alignment_buffer_.data(), complete_packets);
      }
      packet_alignment_buffer_.erase(
          packet_alignment_buffer_.begin(),
          packet_alignment_buffer_.begin() + complete_packets);
    }
    
    // Warn if partial packet remains
    if (!packet_alignment_buffer_.empty()) {
      std::cerr << "[EncoderPipeline] WARNING: Partial TS packet discarded on close | "
                << "size=" << packet_alignment_buffer_.size() << " bytes" << std::endl;
      packet_alignment_buffer_.clear();
    }
  }

  // Close AVIO
  if (custom_avio_ctx_) {
    // Custom AVIO - free it
    if (custom_avio_ctx_->buffer) {
      av_freep(&custom_avio_ctx_->buffer);
    }
    avio_context_free(&custom_avio_ctx_);
    format_ctx_->pb = nullptr;
  } else if (format_ctx_ && format_ctx_->pb && !(format_ctx_->oformat->flags & AVFMT_NOFILE)) {
    // URL-based AVIO - close it
    avio_closep(&format_ctx_->pb);
  }
  
  avio_opaque_ = nullptr;
  avio_write_callback_ = nullptr;

  // Free resources
  if (frame_ && frame_->data[0]) {
    av_freep(&frame_->data[0]);
  }
  av_frame_free(&frame_);
  
  if (input_frame_ && input_frame_->data[0]) {
    av_freep(&input_frame_->data[0]);
  }
  av_frame_free(&input_frame_);
  
  av_packet_free(&packet_);
  avcodec_free_context(&codec_ctx_);
  avformat_free_context(format_ctx_);
  format_ctx_ = nullptr;
  
  if (sws_ctx_) {
    sws_freeContext(sws_ctx_);
    sws_ctx_ = nullptr;
  }
  sws_ctx_valid_ = false;

  video_stream_ = nullptr;
  frame_width_ = 0;
  frame_height_ = 0;
  header_written_ = false;
#endif

  initialized_ = false;
  std::cout << "[EncoderPipeline] Encoder pipeline closed" << std::endl;
}

bool EncoderPipeline::IsInitialized() const {
  return initialized_;
}

#ifdef RETROVUE_FFMPEG_AVAILABLE
// Note: avioWriteCallback is no longer used - we use the callback directly

// Extract PID from TS packet (bytes 1-2)
uint16_t EncoderPipeline::ExtractPID(const uint8_t* ts_packet) {
  if (!ts_packet || ts_packet[0] != 0x47) {
    return 0xFFFF;  // Invalid
  }
  return ((ts_packet[1] & 0x1F) << 8) | ts_packet[2];
}

// Extract continuity counter from TS packet (byte 3, lower 4 bits)
uint8_t EncoderPipeline::ExtractContinuityCounter(const uint8_t* ts_packet) {
  if (!ts_packet || ts_packet[0] != 0x47) {
    return 0xFF;  // Invalid
  }
  return ts_packet[3] & 0x0F;
}

// Extract PCR from TS packet adaptation field (if present)
bool EncoderPipeline::ExtractPCR(const uint8_t* ts_packet, int64_t& pcr_90k) {
  if (!ts_packet || ts_packet[0] != 0x47) {
    return false;
  }
  
  // Check if adaptation field is present (bit 4 of byte 3)
  if (!(ts_packet[3] & 0x20)) {
    return false;  // No adaptation field
  }
  
  // Byte 4: adaptation_field_length
  uint8_t adaptation_field_length = ts_packet[4];
  if (adaptation_field_length == 0) {
    return false;  // No adaptation field data
  }
  
  // Byte 5: adaptation_field_control flags (bit 4 = PCR flag)
  if (!(ts_packet[5] & 0x10)) {
    return false;  // No PCR flag set
  }
  
  // PCR is 6 bytes starting at byte 6 (after adaptation_field_length and flags)
  // PCR = (33-bit base) * 300 + (9-bit extension)
  // But we only need the base for 90kHz conversion
  int64_t pcr_base = ((int64_t)ts_packet[6] << 25) |
                     ((int64_t)ts_packet[7] << 17) |
                     ((int64_t)ts_packet[8] << 9) |
                     ((int64_t)ts_packet[9] << 1) |
                     ((ts_packet[10] >> 7) & 0x01);
  int64_t pcr_ext = ((ts_packet[10] & 0x01) << 8) | ts_packet[11];
  
  // Convert to 90kHz units (PCR is in 27MHz, divide by 300)
  // pcr_base is in 27MHz units, so pcr_90k = pcr_base / 300
  pcr_90k = pcr_base;
  
  return true;
}

// Process TS packets and validate continuity counters
void EncoderPipeline::ProcessTSPackets(const uint8_t* data, size_t size) {
  const size_t ts_packet_size = 188;
  size_t offset = 0;
  
  while (offset + ts_packet_size <= size) {
    const uint8_t* ts_packet = data + offset;
    
    // Validate sync byte
    if (ts_packet[0] != 0x47) {
      std::cerr << "[EncoderPipeline] Invalid TS sync byte at offset " << offset << std::endl;
      offset += 1;  // Skip one byte and try to resync
      continue;
    }
    
    // Extract PID and continuity counter
    uint16_t pid = ExtractPID(ts_packet);
    uint8_t cc = ExtractContinuityCounter(ts_packet);
    
    // Check if payload unit start indicator is set (bit 6 of byte 1)
    bool payload_start = (ts_packet[1] & 0x40) != 0;
    
    // Track continuity counter
    if (continuity_counters_.find(pid) != continuity_counters_.end()) {
      uint8_t expected_cc = (continuity_counters_[pid] + 1) & 0x0F;
      if (cc != expected_cc && payload_start) {
        // Allow discontinuity if payload_start is set (new PES packet)
        // But log it for monitoring
        static uint64_t discontinuity_count = 0;
        if (discontinuity_count++ % 100 == 0) {
          std::cout << "[EncoderPipeline] Continuity counter discontinuity detected | "
                    << "PID=" << pid << " | expected=" << (int)expected_cc 
                    << " | got=" << (int)cc << std::endl;
        }
      }
    }
    
    continuity_counters_[pid] = cc;
    
    // Extract and track PCR if present
    int64_t pcr_90k = 0;
    if (ExtractPCR(ts_packet, pcr_90k)) {
      auto now = std::chrono::steady_clock::now();
      int64_t now_us = std::chrono::duration_cast<std::chrono::microseconds>(
          now.time_since_epoch()).count();
      
      if (last_pcr_valid_) {
        // Validate PCR cadence (should be ~40ms apart, allow 20-60ms range)
        int64_t pcr_diff = pcr_90k - last_pcr_90k_;
        int64_t time_diff_us = now_us - last_pcr_packet_time_us_;
        int64_t expected_pcr_diff = (time_diff_us * 90) / 1000;  // Convert us to 90kHz
        
        // Allow some tolerance (20-60ms)
        if (pcr_diff < (expected_pcr_diff * 20 / 40) || 
            pcr_diff > (expected_pcr_diff * 60 / 40)) {
          static uint64_t pcr_warning_count = 0;
          if (pcr_warning_count++ % 100 == 0) {
            std::cout << "[EncoderPipeline] PCR cadence warning | "
                      << "PCR_diff=" << pcr_diff << " | "
                      << "time_diff=" << (time_diff_us / 1000) << "ms" << std::endl;
          }
        }
      }
      
      last_pcr_90k_ = pcr_90k;
      last_pcr_packet_time_us_ = now_us;
      last_pcr_valid_ = true;
    }
    
    offset += ts_packet_size;
  }
}

// Validate that data is aligned on 188-byte TS packet boundaries
bool EncoderPipeline::ValidatePacketAlignment(const uint8_t* data, size_t size) {
  const size_t ts_packet_size = 188;
  
  // Check if size is multiple of 188
  if (size % ts_packet_size != 0) {
    return false;
  }
  
  // Check sync bytes at expected positions
  for (size_t i = 0; i < size; i += ts_packet_size) {
    if (data[i] != 0x47) {
      return false;
    }
  }
  
  return true;
}

// Write with packet alignment - ensures TS packets (188 bytes) are never split
bool EncoderPipeline::WriteWithAlignment(const uint8_t* data, size_t size) {
  const size_t ts_packet_size = 188;
  const size_t max_buffer_size = 1024 * 1024;  // 1MB max buffer size
  
  // Check if buffer would exceed max size
  if (packet_alignment_buffer_.size() + size > max_buffer_size) {
    // Buffer too large - drop oldest data to make room
    // This prevents unbounded growth when writes keep failing
    size_t drop_size = (packet_alignment_buffer_.size() + size) - max_buffer_size;
    drop_size = (drop_size / ts_packet_size + 1) * ts_packet_size;  // Round up to packet boundary
    if (drop_size < packet_alignment_buffer_.size()) {
      packet_alignment_buffer_.erase(
          packet_alignment_buffer_.begin(),
          packet_alignment_buffer_.begin() + drop_size);
      std::cerr << "[EncoderPipeline] Alignment buffer overflow - dropped " 
                << drop_size << " bytes" << std::endl;
    } else {
      packet_alignment_buffer_.clear();
    }
  }
  
  // Add to alignment buffer
  packet_alignment_buffer_.insert(packet_alignment_buffer_.end(), data, data + size);
  
  // Process complete TS packets
  size_t complete_packets = (packet_alignment_buffer_.size() / ts_packet_size) * ts_packet_size;
  
  if (complete_packets > 0) {
    // Write complete packets
    // Call the C-style callback directly (it always returns buf_size)
    if (avio_write_callback_ && avio_opaque_) {
      int result = avio_write_callback_(avio_opaque_, packet_alignment_buffer_.data(), complete_packets);
      // Callback always returns buf_size (never blocks, never returns < buf_size)
      // So we can always proceed
    } else {
      // No callback - can't write
      return false;
    }
    
    // Process and validate TS packets
    ProcessTSPackets(packet_alignment_buffer_.data(), complete_packets);
    
    // Remove written packets from buffer
    packet_alignment_buffer_.erase(
        packet_alignment_buffer_.begin(),
        packet_alignment_buffer_.begin() + complete_packets);
  }
  
  return true;
}
#endif  // RETROVUE_FFMPEG_AVAILABLE

#else
// Stub implementations when FFmpeg is not available

EncoderPipeline::EncoderPipeline(const MpegTSPlayoutSinkConfig& config)
    : config_(config), initialized_(false) {
}

EncoderPipeline::~EncoderPipeline() {
  close();
}

bool EncoderPipeline::open(const MpegTSPlayoutSinkConfig& config) {
  if (initialized_) {
    return true;
  }

  std::cerr << "[EncoderPipeline] ERROR: FFmpeg not available. Rebuild with FFmpeg to enable real encoding." << std::endl;
  initialized_ = true;  // Allow stub mode to continue
  return true;
}

bool EncoderPipeline::encodeFrame(const retrovue::buffer::Frame& frame, int64_t pts90k) {
  if (!initialized_) {
    return false;
  }

  // Stub: just log
  std::cout << "[EncoderPipeline] encodeFrame() - FFmpeg not available | PTS=" << pts90k
            << " | size=" << frame.width << "x" << frame.height << std::endl;
  return true;
}

void EncoderPipeline::close() {
  if (!initialized_) {
    return;
  }

  std::cout << "[EncoderPipeline] close() - FFmpeg not available" << std::endl;
  initialized_ = false;
}

bool EncoderPipeline::IsInitialized() const {
  return initialized_;
}

#endif  // RETROVUE_FFMPEG_AVAILABLE

}  // namespace retrovue::playout_sinks::mpegts
