// Repository: Retrovue-playout
// Component: Fake MasterClock for Testing
// Purpose: Controllable fake clock for deterministic timing tests.
// Copyright (c) 2025 RetroVue

#ifndef RETROVUE_TESTS_FIXTURES_MPEGTS_SINK_FAKE_MASTER_CLOCK_H_
#define RETROVUE_TESTS_FIXTURES_MPEGTS_SINK_FAKE_MASTER_CLOCK_H_

#include "retrovue/timing/MasterClock.h"
#include <atomic>
#include <cstdint>

namespace retrovue::tests::fixtures::mpegts_sink {

// FakeMasterClock provides a controllable clock for testing.
// Time advances only when explicitly called via advance_us().
// No real sleeping - tests control time deterministically.
class FakeMasterClock : public retrovue::timing::MasterClock {
 public:
  explicit FakeMasterClock(int64_t start_time_us = 1'000'000'000'000'000)
      : current_time_us_(start_time_us) {}

  // MasterClock interface
  int64_t now_utc_us() const override {
    return current_time_us_.load(std::memory_order_acquire);
  }

  double now_monotonic_s() const override {
    return static_cast<double>(now_utc_us()) / 1'000'000.0;
  }

  int64_t scheduled_to_utc_us(int64_t pts_us) const override {
    // For testing: assume PTS maps directly to UTC (no schedule offset)
    return pts_us;
  }

  double drift_ppm() const override {
    return 0.0;
  }

  bool is_fake() const override {
    return true;
  }

  // Test control methods
  void advance_us(int64_t delta_us) {
    current_time_us_.fetch_add(delta_us, std::memory_order_acq_rel);
  }

  void set_time_us(int64_t time_us) {
    current_time_us_.store(time_us, std::memory_order_release);
  }

  int64_t get_time_us() const {
    return current_time_us_.load(std::memory_order_acquire);
  }

 private:
  std::atomic<int64_t> current_time_us_;
};

}  // namespace retrovue::tests::fixtures::mpegts_sink

#endif  // RETROVUE_TESTS_FIXTURES_MPEGTS_SINK_FAKE_MASTER_CLOCK_H_

